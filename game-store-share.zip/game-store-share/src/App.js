import './App.css';
import Page from "./display.js";

function App() {
  return (
    <div className="App">
      <Page/>
    </div>
  );
}

export default App;
