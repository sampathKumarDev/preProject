export default function Page () {

    return (

        <div class="main">
            <div class="top">
                <div class="top-left">
                    <div class="header">
                        <div></div>
                        <h1>Gaming Zone</h1>
                    </div>
                    <div class="image">
                        <img src={require("./pubg.jpg")} alt="img"></img>
                    </div>
                </div>
                <div class="top-right">
                    <h3>PUBG</h3>
                    <p>
                        eu dolore reprehenderit voluptate consequat esse cupidatat pariatur sunt laborum fugiat
                        labore enim consectetur nulla tempor amet culpa quis velit velit veniam dolore consectetur 
                        est elit Lorem commodo excepteur culpa ex nulla amet proident elit nisi excepteur voluptate 
                        ex culpa consequat proident exercitation cupidatat ex cupidatat do consequat nostrud laborum 
                        irure in sit id veniam pariatur aute minim deserunt labore Lorem culpa laborum consequat eu
                    </p>
                    <button> Subscribe</button>
                </div>
            </div>
            <div class="bottom">
                <h3>More Details</h3>
                <p>
                    eu dolore reprehenderit voluptate consequat esse cupidatat pariatur sunt laborum fugiat
                    labore enim consectetur nulla tempor amet culpa quis velit velit veniam dolore consectetur 
                    est elit Lorem commodo excepteur culpa ex nulla amet proident elit nisi excepteur voluptate 
                </p>
                <h3>Reviews</h3>
                <p>
                    eu dolore reprehenderit voluptate consequat esse cupidatat pariatur sunt laborum fugiat
                    labore enim consectetur nulla tempor amet culpa quis velit velit veniam dolore consectetur 
                    est elit Lorem commodo excepteur culpa ex nulla amet proident elit nisi excepteur voluptate 
                </p>
            </div>
        </div>
    )
}